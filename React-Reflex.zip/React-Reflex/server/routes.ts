import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import crypto from "crypto";

function formatDate(date: Date): string {
  return date.toISOString().replace('T', ' ').substring(0, 19);
}

function hashIP(ip: string): string {
  return crypto.createHash('sha256').update(ip + process.env.SESSION_SECRET).digest('hex');
}

function getClientIP(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/can-play", async (req, res) => {
    try {
      const clientIP = getClientIP(req);
      const ipHash = hashIP(clientIP);
      const hasPlayed = await storage.hasPlayedByIpHash(ipHash);
      return res.json({ canPlay: !hasPlayed });
    } catch (error) {
      console.error("Error checking play status:", error);
      return res.json({ canPlay: true });
    }
  });
  
  app.get("/api/results/download/csv", async (req, res) => {
    const password = req.query.password;
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    try {
      const results = await storage.getReactionResults();
      
      const headers = ["ID", "Average (ms)", "Trial 1", "Trial 2", "Trial 3", "Trial 4", "Trial 5", "Date/Time", "User Agent"];
      const rows = results.map(r => [
        r.id,
        r.averageMs,
        r.trials[0] || '',
        r.trials[1] || '',
        r.trials[2] || '',
        r.trials[3] || '',
        r.trials[4] || '',
        formatDate(r.createdAt),
        `"${(r.userAgent || '').replace(/"/g, '""')}"`
      ].join(','));
      
      const csv = [headers.join(','), ...rows].join('\n');
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="reaction_time_results.csv"');
      return res.send(csv);
    } catch (error) {
      console.error("Error exporting CSV:", error);
      return res.status(500).json({ success: false, error: "Failed to export data" });
    }
  });

  app.get("/api/results/download/txt", async (req, res) => {
    const password = req.query.password;
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    try {
      const results = await storage.getReactionResults();
      
      const lines = results.map((r, i) => {
        return [
          `=== Result ${i + 1} ===`,
          `ID: ${r.id}`,
          `Date/Time: ${formatDate(r.createdAt)}`,
          `Average: ${r.averageMs}ms`,
          `Trials: ${r.trials.join('ms, ')}ms`,
          `User Agent: ${r.userAgent || 'N/A'}`,
          ''
        ].join('\n');
      });
      
      const txt = `Reaction Time Test Results\nExported: ${formatDate(new Date())}\nTotal Results: ${results.length}\n\n${lines.join('\n')}`;
      
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', 'attachment; filename="reaction_time_results.txt"');
      return res.send(txt);
    } catch (error) {
      console.error("Error exporting TXT:", error);
      return res.status(500).json({ success: false, error: "Failed to export data" });
    }
  });

  app.post("/api/results", async (req, res) => {
    try {
      const clientIP = getClientIP(req);
      const ipHash = hashIP(clientIP);

      const hasPlayed = await storage.hasPlayedByIpHash(ipHash);
      if (hasPlayed) {
        return res.status(403).json({ 
          success: false, 
          error: "You have already completed this test" 
        });
      }

      const bodySchema = z.object({
        averageMs: z.number().int().positive(),
        trials: z.array(z.number().int().positive()).length(5),
        userAgent: z.string().optional(),
      });

      const parsed = bodySchema.safeParse(req.body);
      
      if (!parsed.success) {
        return res.status(400).json({ 
          success: false, 
          error: "Invalid request data",
          details: parsed.error.flatten()
        });
      }

      const result = await storage.createReactionResult({
        averageMs: parsed.data.averageMs,
        trials: parsed.data.trials,
        userAgent: parsed.data.userAgent || null,
        ipHash: ipHash,
      });

      return res.status(201).json({ 
        success: true, 
        result 
      });
    } catch (error) {
      console.error("Error saving reaction result:", error);
      return res.status(500).json({ 
        success: false, 
        error: "Failed to save result" 
      });
    }
  });

  app.get("/api/results", async (req, res) => {
    const password = req.query.password;
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    try {
      const results = await storage.getReactionResults();
      return res.json({ success: true, results });
    } catch (error) {
      console.error("Error fetching results:", error);
      return res.status(500).json({ 
        success: false, 
        error: "Failed to fetch results" 
      });
    }
  });

  app.get("/api/results/:id", async (req, res) => {
    try {
      const result = await storage.getReactionResult(req.params.id);
      if (!result) {
        return res.status(404).json({ 
          success: false, 
          error: "Result not found" 
        });
      }
      return res.json({ success: true, result });
    } catch (error) {
      console.error("Error fetching result:", error);
      return res.status(500).json({ 
        success: false, 
        error: "Failed to fetch result" 
      });
    }
  });

  return httpServer;
}

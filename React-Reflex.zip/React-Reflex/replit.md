# Reaction Time Test Application

## Overview

This is a reaction time testing web application that measures user reflexes through a 5-trial test. Users click/tap when a visual indicator changes color, and their response times are recorded, averaged, and stored in a database. The application prioritizes clarity, instant visual feedback, and mobile-first design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state, local React state for UI
- **Styling**: Tailwind CSS with CSS variables for theming
- **Component Library**: shadcn/ui (Radix UI primitives with custom styling)
- **Build Tool**: Vite with HMR support

The frontend follows a single-page application pattern with the main test interface on the home route. Components are organized with UI primitives in `client/src/components/ui/` and pages in `client/src/pages/`.

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Pattern**: RESTful JSON endpoints under `/api/`
- **Development**: Vite dev server proxied through Express for unified development experience

The server handles API routes first, then falls back to serving the Vite-built frontend. In development, Vite middleware provides hot module replacement.

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with Zod schema validation
- **Schema Location**: `shared/schema.ts` (shared between client and server)
- **Migrations**: Drizzle Kit with `db:push` command

Key tables:
- `reaction_results`: Stores test results with average time (ms), individual trial times array, user agent, and timestamp
- `users`: Basic user table (username/password) for potential future authentication

### API Structure
- `POST /api/results`: Save a completed test (averageMs, trials array, userAgent)
- `GET /api/results`: Retrieve recent test results (last 100, ordered by date)

### Project Structure
```
client/           # React frontend
  src/
    components/ui/  # shadcn/ui components
    pages/          # Route components
    hooks/          # Custom React hooks
    lib/            # Utilities (queryClient, utils)
server/           # Express backend
  routes.ts       # API route handlers
  storage.ts      # Database operations
  db.ts           # Database connection
shared/           # Shared code (schema)
```

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connected via `DATABASE_URL` environment variable
- **pg**: Node.js PostgreSQL client
- **drizzle-orm**: Type-safe ORM for database operations

### UI Framework
- **Radix UI**: Accessible component primitives (dialog, toast, tooltip, etc.)
- **Tailwind CSS**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Tools
- **Vite**: Frontend build tool with React plugin
- **esbuild**: Server bundling for production
- **tsx**: TypeScript execution for development

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal**: Error overlay in development
- **@replit/vite-plugin-cartographer**: Development tooling
- **@replit/vite-plugin-dev-banner**: Development banner
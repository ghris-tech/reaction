import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, FileText, Table, Lock, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function Admin() {
  const [password, setPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    try {
      const response = await fetch(`/api/results?password=${encodeURIComponent(password)}`);
      if (response.ok) {
        setIsAuthenticated(true);
      } else {
        setError("Invalid password");
      }
    } catch {
      setError("Failed to authenticate");
    }
  };

  const handleDownload = (format: 'csv' | 'txt') => {
    window.location.href = `/api/results/download/${format}?password=${encodeURIComponent(password)}`;
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-sm border border-card-border">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Lock className="h-12 w-12 text-muted-foreground" />
            </div>
            <CardTitle className="text-xl">Admin Access</CardTitle>
            <CardDescription>Enter password to view and download results</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter admin password"
                  data-testid="input-password"
                />
              </div>
              {error && (
                <div className="text-sm text-red-600 dark:text-red-400" data-testid="text-error">
                  {error}
                </div>
              )}
              <Button type="submit" className="w-full" data-testid="button-login">
                Access Results
              </Button>
            </form>
            <div className="mt-4 text-center">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-muted-foreground">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Test
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <h1 className="text-2xl font-semibold">Results Admin</h1>
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Test
            </Button>
          </Link>
        </div>

        <Card className="border border-card-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Download className="h-5 w-5" />
              Download Results
            </CardTitle>
            <CardDescription>
              Export all reaction time test data with date/time stamps
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button 
                onClick={() => handleDownload('csv')} 
                variant="outline"
                className="h-auto py-4 flex flex-col items-center gap-2"
                data-testid="button-download-csv"
              >
                <Table className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Download CSV</div>
                  <div className="text-xs text-muted-foreground">Opens in Excel/Sheets</div>
                </div>
              </Button>
              <Button 
                onClick={() => handleDownload('txt')} 
                variant="outline"
                className="h-auto py-4 flex flex-col items-center gap-2"
                data-testid="button-download-txt"
              >
                <FileText className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Download TXT</div>
                  <div className="text-xs text-muted-foreground">Plain text format</div>
                </div>
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Each download includes: ID, average time, all 5 trial times, date/time, and user agent.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

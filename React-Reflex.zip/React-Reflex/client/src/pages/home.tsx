import { useState, useEffect, useCallback, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, RotateCcw } from "lucide-react";

type GameState = "ready" | "countdown" | "waiting" | "go" | "recorded" | "done" | "blocked";

export default function Home() {
  const [gameState, setGameState] = useState<GameState>("ready");
  const [countdownNumber, setCountdownNumber] = useState(3);
  const [trials, setTrials] = useState<number[]>([]);
  const [lastReaction, setLastReaction] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const goTimeRef = useRef<number>(0);

  const { data: canPlayData, isLoading: checkingAccess } = useQuery<{ canPlay: boolean }>({
    queryKey: ['/api/can-play'],
  });

  useEffect(() => {
    if (canPlayData && canPlayData.canPlay === false) {
      setGameState("blocked");
    }
  }, [canPlayData]);

  const submitMutation = useMutation({
    mutationFn: async (data: { averageMs: number; trials: number[]; userAgent: string }) => {
      const response = await apiRequest("POST", "/api/results", data);
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
    },
    onError: (error: Error) => {
      setIsSubmitting(false);
      setSubmitError(error.message);
    },
  });

  const randDelay = () => 1500 + Math.floor(Math.random() * 2500);

  const startCountdown = useCallback(() => {
    setGameState("countdown");
    setCountdownNumber(3);
    
    let count = 3;
    const countdownInterval = setInterval(() => {
      count--;
      if (count > 0) {
        setCountdownNumber(count);
      } else {
        clearInterval(countdownInterval);
        startWaiting();
      }
    }, 1000);
  }, []);

  const startWaiting = useCallback(() => {
    setGameState("waiting");
    const delay = randDelay();
    
    timeoutRef.current = setTimeout(() => {
      goTimeRef.current = performance.now();
      setGameState("go");
    }, delay);
  }, []);

  const handleTap = useCallback(() => {
    if (gameState === "ready") {
      startCountdown();
    } else if (gameState === "waiting") {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      setGameState("ready");
    } else if (gameState === "go") {
      const reactionTime = Math.round(performance.now() - goTimeRef.current);
      setLastReaction(reactionTime);
      const newTrials = [...trials, reactionTime];
      setTrials(newTrials);
      
      if (newTrials.length >= 5) {
        setGameState("done");
        const avg = Math.round(newTrials.reduce((a, b) => a + b, 0) / newTrials.length);
        setIsSubmitting(true);
        submitMutation.mutate({
          averageMs: avg,
          trials: newTrials,
          userAgent: navigator.userAgent || "",
        });
      } else {
        setGameState("recorded");
        setTimeout(() => {
          startCountdown();
        }, 1500);
      }
    }
  }, [gameState, trials, startCountdown, submitMutation]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.key === "Enter") {
        e.preventDefault();
        if (gameState !== "done" && gameState !== "blocked" && gameState !== "countdown") {
          handleTap();
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleTap, gameState]);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const average = trials.length > 0 
    ? Math.round(trials.reduce((a, b) => a + b, 0) / trials.length)
    : 0;

  const bestTime = trials.length > 0 ? Math.min(...trials) : 0;
  const worstTime = trials.length > 0 ? Math.max(...trials) : 0;

  if (checkingAccess) {
    return (
      <div 
        className="min-h-screen bg-black flex items-center justify-center cursor-pointer select-none"
        data-testid="screen-loading"
      >
        <div className="text-white text-4xl md:text-6xl font-light tracking-wide animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  if (gameState === "blocked") {
    return (
      <div 
        className="min-h-screen bg-black flex items-center justify-center select-none"
        data-testid="screen-blocked"
      >
        <div className="text-center">
          <div className="text-white text-3xl md:text-5xl font-light tracking-wide mb-4">
            Already Played
          </div>
          <div className="text-gray-500 text-lg md:text-xl">
            You can only take this test once.
          </div>
        </div>
      </div>
    );
  }

  if (gameState === "done") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 animate-in fade-in duration-500">
        <Card className="w-full max-w-md border border-card-border" data-testid="card-results">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-xl font-semibold">Your Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center py-6">
              <div className="text-6xl md:text-7xl font-bold text-foreground tabular-nums" data-testid="text-average">
                {average}
              </div>
              <div className="text-xl text-muted-foreground mt-1">milliseconds</div>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {trials.map((time, i) => (
                <div
                  key={i}
                  className={`p-3 rounded-md text-center transition-all ${
                    time === bestTime
                      ? "bg-green-500/10 dark:bg-green-500/20 border border-green-500/30"
                      : time === worstTime
                      ? "bg-red-500/10 dark:bg-red-500/20 border border-red-500/30"
                      : "bg-muted border border-border"
                  }`}
                  data-testid={`card-trial-result-${i}`}
                >
                  <div className="text-xs text-muted-foreground mb-1">#{i + 1}</div>
                  <div className={`text-lg font-semibold tabular-nums ${
                    time === bestTime
                      ? "text-green-700 dark:text-green-300"
                      : time === worstTime
                      ? "text-red-700 dark:text-red-300"
                      : "text-foreground"
                  }`}>
                    {time}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground pt-2 border-t border-border">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>Best: {bestTime}ms</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <span>Worst: {worstTime}ms</span>
              </div>
            </div>

            {isSubmitting && (
              <div className="text-center text-sm text-muted-foreground" data-testid="status-submitting">
                Saving your results...
              </div>
            )}
            {submitSuccess && (
              <div className="flex items-center justify-center gap-2 text-sm text-green-600 dark:text-green-400" data-testid="status-success">
                <Check className="h-4 w-4" />
                Results saved!
              </div>
            )}
            {submitError && (
              <div className="text-center text-sm text-red-600 dark:text-red-400" data-testid="status-error">
                Failed to save: {submitError}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  const getBackgroundColor = () => {
    switch (gameState) {
      case "go":
        return "bg-green-500";
      default:
        return "bg-black";
    }
  };

  const getText = () => {
    switch (gameState) {
      case "ready":
        return "Ready?";
      case "countdown":
        return countdownNumber.toString();
      case "waiting":
        return "Wait...";
      case "go":
        return "TAP!";
      case "recorded":
        return `${lastReaction}ms`;
      default:
        return "";
    }
  };

  const getSubtext = () => {
    switch (gameState) {
      case "ready":
        return "Tap anywhere to begin";
      case "waiting":
        return `Trial ${trials.length + 1} of 5`;
      case "recorded":
        return `Trial ${trials.length} of 5 complete`;
      default:
        return "";
    }
  };

  return (
    <div 
      className={`min-h-screen flex flex-col items-center justify-center cursor-pointer select-none transition-colors duration-100 ${getBackgroundColor()}`}
      onClick={handleTap}
      data-testid="game-screen"
    >
      <div className="text-center">
        <div 
          className={`text-6xl md:text-9xl font-light tracking-wide transition-all duration-200 ${
            gameState === "go" ? "text-black" : "text-white"
          }`}
          data-testid="text-main"
        >
          {getText()}
        </div>
        {getSubtext() && (
          <div 
            className={`mt-8 text-lg md:text-xl font-light tracking-wide ${
              gameState === "go" ? "text-black/70" : "text-gray-500"
            }`}
            data-testid="text-sub"
          >
            {getSubtext()}
          </div>
        )}
      </div>
    </div>
  );
}

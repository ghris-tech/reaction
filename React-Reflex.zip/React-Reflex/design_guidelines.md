# Design Guidelines: Reaction Time Test Application

## Design Approach
**System-Based Approach** - This is a utility-focused testing tool prioritizing clarity, functionality, and data presentation. Drawing inspiration from productivity tools like Linear and data visualization apps, we emphasize clean typography, clear visual states, and efficient information hierarchy.

## Core Design Principles
1. **Instant Visual Feedback**: Color-coded states must be immediately recognizable
2. **Distraction-Free Testing**: Minimal interface during active trials
3. **Data Clarity**: Results presentation prioritizes readability and quick comprehension
4. **Mobile-First**: Touch-friendly targets, responsive at all sizes

---

## Typography System

**Primary Font**: Inter or Geist (via Google Fonts CDN)
- Headings: 600 weight, tight tracking (-0.02em)
- Body: 400 weight, relaxed line-height (1.6)
- Data/Numbers: 500 weight, tabular-nums for alignment

**Hierarchy**:
- Page Title: text-2xl md:text-3xl font-semibold
- Section Headers: text-lg font-medium
- Instructions: text-base text-gray-600
- Data/Stats: text-4xl md:text-5xl font-medium (for reaction times)
- Helper Text: text-sm text-gray-500

---

## Layout System

**Spacing Units**: Consistent use of 4, 6, 8, 12, 16, 24 (p-4, gap-6, py-8, mb-12, etc.)

**Container Strategy**:
- Test interface: max-w-2xl mx-auto (centered, focused)
- Full width background for visual breathing room
- Card-based design with generous padding (p-8 md:p-12)
- Section spacing: space-y-8 for vertical rhythm

---

## Component Library

### Test Interface Card
- Elevated card with soft shadow (shadow-lg)
- Rounded corners (rounded-2xl)
- White background with subtle border
- Responsive padding: p-6 md:p-10

### Interactive Test Button (Primary Focus)
**Critical Component** - This is the core interaction element:
- Massive touch target: min-h-48 md:min-h-64
- Rounded corners: rounded-xl
- Border thickness: border-4 for clear state indication
- Typography: text-2xl md:text-3xl font-semibold

**State Visual Language**:
- **Idle/Start**: Neutral gray background, subtle border, "tap to begin" messaging
- **Waiting**: Darker gray, pulsing border animation (subtle), "wait..." text
- **Go State**: Vibrant green background, green border, "TAP NOW!" text
- **Early Click**: Red background, red border, "Too early!" text
- **Recorded**: Soft blue/gray, checkmark or "Recorded" confirmation

Include smooth transitions between states (transition-all duration-200)

### Results Display Panel
**Trial-by-Trial Breakdown**:
- Grid layout: grid-cols-5 gap-3 for 5 trials
- Each trial: Individual card showing milliseconds
- Visual indicator for best/worst times (subtle highlight)

**Average Display**:
- Hero-sized number: text-6xl md:text-7xl font-bold
- "ms" unit in smaller text: text-2xl text-gray-500
- Centered with ample spacing (py-12)

**Data Summary Section**:
- Clean table or definition list for detailed stats
- User agent info collapsed by default (expandable detail)
- Timestamp of test completion

### Status Messages
- Alert-style component for instructions
- Icon + text combination for clarity
- Color-coded by message type (info, success, warning, error)
- Positioned above test button with mb-4

### Secondary Actions
- Text-style buttons for "Reset" or "Try Again"
- Positioned below results, understated styling
- text-sm underline hover:no-underline pattern

---

## Visual States & Feedback

**Button States** (beyond color changes):
- Disabled state during processing
- Loading spinner when submitting data
- Success animation on completion (brief scale or checkmark)

**Page States**:
1. **Welcome/Instructions** (pre-test)
2. **Active Testing** (trials 1-5)
3. **Results** (post-test with data)
4. **Error State** (if data submission fails)

---

## Responsive Behavior

**Mobile (base)**:
- Single column, full attention on test button
- Larger touch targets (min 44px)
- Simplified instruction text

**Desktop (md: and up)**:
- Maintain centered focus, don't spread too wide
- Optional sidebar for "How it works" or leaderboard
- Larger typography for easier reading from distance

---

## Accessibility Features

- High contrast ratios (WCAG AAA for test states)
- Keyboard navigation: Space/Enter to activate button
- Clear focus indicators (ring-4 ring-blue-500)
- Aria-live regions for status updates
- Screen reader announcements for state changes

---

## Animation & Motion

**Minimal and Purposeful**:
- Button state transitions: 200ms ease-in-out
- Pulse effect on "waiting" state (2s loop, subtle opacity change)
- Success confetti or checkmark animation on completion (1-time, brief)
- No parallax, no continuous animations during testing

**NO animations during active test** (between "go" signal and user tap)

---

## Page Structure

**Single-Page Application**:
1. **Header** (minimal): Logo/title + "About" link
2. **Test Interface** (main focus): Centered card with button
3. **Results Section** (conditional): Appears after completion
4. **Footer** (simple): Credits, privacy note, version

**No hero image** - this is a tool, not marketing. Focus stays on functionality.

---

## Data Visualization

**If adding leaderboard/historical data**:
- Bar chart for personal history (simple, no complex libraries)
- Percentile indicator ("faster than X% of users")
- Clean table with sortable columns
- Use chart.js or similar lightweight library

---

## Key Design Differentiators

Unlike typical reaction test sites:
- **Professional grade**: Looks like a research tool, not a game
- **Data-focused**: Emphasis on accurate recording and clear results
- **Minimal cognitive load**: Zero distractions during test
- **Scientific aesthetic**: Clean, precise, trustworthy
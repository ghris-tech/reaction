import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const reactionResults = pgTable("reaction_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  averageMs: integer("average_ms").notNull(),
  trials: integer("trials").array().notNull(),
  userAgent: text("user_agent"),
  ipHash: text("ip_hash"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertReactionResultSchema = createInsertSchema(reactionResults).omit({
  id: true,
  createdAt: true,
});

export type InsertReactionResult = z.infer<typeof insertReactionResultSchema>;
export type ReactionResult = typeof reactionResults.$inferSelect;
